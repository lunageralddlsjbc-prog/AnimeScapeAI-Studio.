ANIMESCAPE AI STUDIO — GITHUB UPLOAD

1. Create a NEW empty GitHub repository named AnimeScapeAI-Studio.
2. Extract this package on your Android phone.
3. Upload AnimeScapeAI-Studio-source.zip to the repository root and commit it.
4. In GitHub choose Add file > Create new file.
5. Filename: .github/workflows/main.yml
6. Copy the contents of .github/workflows/main.yml from the extracted source project into the GitHub editor.
7. Commit changes to main.
8. Open Actions > Build AnimeScape AI Studio APK > Run workflow.
9. When successful, download artifact AnimeScapeAI-Studio-debug-apk and install app-debug.apk.

The source ZIP contains the complete Android project. The first APK is an offline anime story/scene planner and prompt builder, not yet a connected AI video renderer.
