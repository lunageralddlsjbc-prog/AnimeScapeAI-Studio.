# AnimeScape AI Studio

Android starter app for planning anime episodes and preparing scene prompts.

## Current capabilities
- Offline story and episode planning
- Anime scene prompt builder
- Environment, lighting, camera and mood presets
- Scene list and JSON project export

## Not yet implemented
This starter does not yet call an AI image/video provider, generate voices/music, render clips, or export MP4. Those require provider integrations, credentials, network handling, and a video assembly pipeline. Free quotas vary by provider.

## Build
The GitHub Actions workflow in `.github/workflows/main.yml` builds a debug APK.
